# Keymap edit
A fork of Keymap Editor (https://github.com/tamland/xbmc-keymap-editor)

Changes so far:
- Added some missing actions introduced in Kodi v17 & v18
- Generated .xml is now properly indented, instead of 1 line
- Rephrased some action categories
- Fixed keymap reloading after save
- Converted to current language formatting
